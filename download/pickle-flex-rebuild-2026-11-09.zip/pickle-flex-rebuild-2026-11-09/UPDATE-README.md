# UPDATE-README — Pickle, flex rebuild tooling, 2026-11-09

**Seat:** pickle · **Branch:** `council/pickle` · **Engine read from:** `origin/architect/engine-and-seats`
tip `3ed03627` (extracted with `git archive` into a private temp dir; no tree was modified). **Read-only:** no
product file, no engine file, no `flex.json` in any tree was changed.

## What this is

The relay `council-zai-prompt-D-custom-table-2026-11-09.md` said: *"`flexrebuild.mjs` does NOT exist — build
it. Claude's manual rebuild timed out, which is exactly the failure a script would prevent."* This is that
script, its verifier, and the complete rule-by-rule diff the Owner asked to see before the table lands.

## Files

| File | What it is |
|---|---|
| `flexrebuild.mjs` | Deterministic rebuild: D (θ=1.0, X=90, Y=70) → nearest tier 0/2/6/12 (cutoffs 1/4/9) → Owner removals/overrides → `flex.json` + `flex.ts` + a markdown report. Flags: `--selftest`, `--check=<flex.json>` (the P-311 gate), `--write=<dir>`, `--slope=wins\|weight`, `--owner=`, `--base=`, `--out-dir=`. |
| `flexverify.mjs` | P-311 verifier, no engine: legal roles/dests/tiers, 7 removals absent, 53 Owner overrides exact, every unnamed rule = rounded D, and `flex.json` ≡ `flex.ts` rule by rule. Flag: `--selftest`. |
| `flex-owner-2026-11-09.json` | The Owner's decisions as data: 7 removals, 53 overrides (2/6/12), θ, X, Y, cutoffs, the WILL 200 / C 200 bumps, and a note on each contested rule. |
| `flex-D-2026-11-09-wins.*` | The generated table under the engine's own slope (`slotWins20/20`) — **the primary table**. `.json` is the full computation, `.md` the rule-by-rule report, `.flex.json` and `.ts` the table in the engine's two shapes. |
| `flex-D-2026-11-09-weight.*` | The same under the weight-ratio slope. Differs from the primary in **3** final rules. |
| `flex-D-2026-11-09.md` | The analysis: findings D-PICKLE-01..04, hypothesis H-PICKLE-01, proposed ruling R-PICKLE-01, receipts. |
| `20261109-1520-pickle-P-317-flexrebuild.md` | The inbox entry (the delivery record). |

## Result

104 rules in → 97 kept, 7 removed, **62 rules move** from the live −2/−6/−12 table.
Tier counts `{0:14, 2:16, 6:18, 12:56}` → `{0:30, 2:16, 6:32, 12:19}` — **exactly 30 rules at 0**, the number
the Owner's relay states the custom table should have. That is an independent convergence check on the whole
chain, not something either side tuned.

## Run it

```bash
# selftests (no engine, ~1 s each)
node tools/mathlab/flexrebuild.mjs --selftest
node tools/mathlab/flexverify.mjs  --selftest

# rebuild (from a colors/ checkout, like thetaprice.mjs)
cd colors
node --experimental-strip-types ../tools/mathlab/flexrebuild.mjs \
  --owner=../tools/mathlab/flex-owner-2026-11-09.json \
  --base=../tools/mathlab/flex.json \
  --out-dir=../tools/mathlab/results

# the whole P-311 review, once a rebuild lands
node --experimental-strip-types ../tools/mathlab/flexrebuild.mjs \
  --owner=../tools/mathlab/flex-owner-2026-11-09.json --check=tools/mathlab/flex.json
# exit 0 = identical to the Owner's rules; exit 1 = every differing rule printed
```

## The three things that change how P-311 is run

1. **The WILL/C weight bump moves D by exactly 0** under the engine's slope (`slotWins20/20` does not read
   `SLOTS[].weight`). P-311 step 2 ("D must be recomputed after the bumps") is a no-op — measured, max Δ = 0.
2. The Owner's *"~6.7 for `OLB>ILB` after the bump"* is true only under a **weight-ratio** slope
   (`10.00 → 6.67`); under the engine's measured slope it is `10.05` and rounds to 12. The Owner's −6 is
   correct **as an override**, not as a rounding result.
3. Three final rules are slope-definition dependent and the Owner did not name them: `TE>FS` (6 vs 2),
   `TE>SS` (6 vs 2), `OG>OT` (2 vs 6). Recommended default: the wins slope, with an explicit Owner line.

## Limits

Nothing here is accepted, implemented or verified on the product. Claude's rebuild has not landed, so P-311
itself is not reviewable yet — this is the instrument, not the review. H-PICKLE-01 (the draft scan of the 30
free rules, starting with `EDGE>OT` and `DT>C`) is pre-registered and not run.
