# DS — flex rebuild package, 2026-11-09/10

The Architect's flex rebuild timed out; this package contains a deterministic generator that reproduces both
tables he landed **rule for rule**, the independent checker that agrees with it, and the 105-rule table for the
Owner's items 3 and 7 (23 at 12 / 40 at 6 / 16 at 2 / 26 at 0 — his own counts).

## The chain (all VERIFIED, receipts in the notes file)

| stage | input | rules | 0/2/6/12 | diff vs the Architect |
|---|---|---|---|---|
| 1 | D@90, θ=1.0, cutoffs 1/4/9, first Owner overrides | 97 | 30/16/32/19 | **0 diffs** vs `35ce4e98` |
| 2 | + the 9 corrections that landed as `728b2c53` | 97 | 23/15/40/19 | **0 diffs** vs `728b2c53` |
| 3 | + Owner items 3 and 7 (TE/LB>FS, SAM destination) | **105** | **26/16/40/23** | target (not built by the Architect) |

Stage 1 and 2 were rebuilt from the original inputs and diffed against the Architect's `flex.json`; stage 3 was
generated, then loaded into a scratch copy of `728b2c53` where `fit()` returns the Owner's exact values for all
ten new/changed rules.

## Findings the Architect needs

1. **The WILL/C weight bump has not landed.** `slots.ts` on `3ed03627`, `35ce4e98`, `728b2c53` is still
   `C 150`, `WILL 150`, `SAM 100`. The flex table is correct; the draft valuation is still the old one.
2. **"Removed" is not "illegal".** A deleted -12 rule becomes the emergency fallback at **-8, legal**
   (`fit('FB','EDGE')` → `{penalty:8, emergency:true, legal:true}`), so P-312(d) fails unless a banned set is
   added. The generated `flex.ts` implements banned with `BANNED_ARE_ILLEGAL = true`.
3. **The weight bump does not move D.** 0 of 97 D values change; `OLB>ILB 6` / `OLB>SS 6` are Owner overrides.
4. **Items 3 + 7 need four engine/test edits** (`Dest` += SAM; SAM slot dest = SAM; `natural()` maps SAM→OLB;
   rule count 97→105), listed in the P-323 note.
5. **3-4 base total:** 2400 on `728b2c53` = 6×(50+300+50); 2700 on the 105 table = 6×(50+300+100).

## Files

- `_agents/ds/notes/flex-rebuild-2026-11-09.md` — full report, six findings, P-312 measurements, integration steps.
- `_agents/ds/notes/HYPOTHESIS-LEDGER.md` — H-DS-004/005 REFUTED, H-DS-006/007 SUPPORTED.
- `_agents/ds/deliveries/flex-rebuild-2026-11-09{,-corrected,-items3-7}/` — `flex.json`, `flex.ts`, `report.md`.
- `tools/mathlab/flexrebuild.mjs` — generator (`--selftest` PASS 36/36).
- `tools/mathlab/flexassert.mjs` — independent checker (`--selftest` PASS 14/14).
- `tools/mathlab/flex-spec-owner-2026-11-09{,-corrected,-items3-7}.json` — decisions as data.
- `tools/mathlab/flex-2026-11-08.json`, `flex-2026-11-09-728.json` — the two base tables.
- `inbox/20261110-0051-ds-P-311-flex-rebuild-review.md` — review of `728b2c53` (VERDICT improved).
- `inbox/20261110-0052-ds-P-323-flex-105-table.md` — the 105-rule WORK proposal.
- `inbox/20261110-0053-ds-P-312-flex-edge-cases.md` — the P-312 playtest.
- `_agents/ds/DS.md` — the lane file.

## How to run

```sh
node tools/mathlab/flexrebuild.mjs --selftest
node tools/mathlab/flexassert.mjs --selftest
node tools/mathlab/flexrebuild.mjs --table=tools/mathlab/flex-2026-11-09-728.json \
  --spec=tools/mathlab/flex-spec-owner-2026-11-09-items3-7.json --mode=apply \
  --out=_agents/ds/deliveries/flex-rebuild-2026-11-09-items3-7
node tools/mathlab/flexassert.mjs \
  --table=_agents/ds/deliveries/flex-rebuild-2026-11-09-items3-7/flex.json \
  --spec=tools/mathlab/flex-spec-owner-2026-11-09-items3-7.json \
  --base=tools/mathlab/flex-2026-11-09-728.json --no-d
```

Expected: `FLEXREBUILD SELFTEST PASS 36/36`, `FLEXASSERT SELFTEST PASS 14/14`,
`FLEXASSERT OK 105 rules, 26 at 0, 0 banned, 105 checked`.

## Build truth

No product file, protected constant or shared tool was edited. `Football-Sim-PreColors.html` is unchanged:
sha256 `40233d6be00e987c472cf6b1126b0ab7f11c123006277466bd23391b308795fd`, 657,486 B.

Not included: `flexeval.mjs` (not in the council tree) and the Architect's engine; this is a proposal package.
