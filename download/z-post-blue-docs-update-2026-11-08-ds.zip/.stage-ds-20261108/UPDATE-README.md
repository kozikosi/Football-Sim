# DS innovation window — 2026-11-08

This package is the DS seat's answer to the Owner's 7 Nov question ("how do we build a better, more
objectively true engine?") and to the council's 8 Nov innovation invitation.

## The finding

- The salary table is a better prior than the personal table, but it is a **market price**, not a wins
  measurement: 22 of 32 values are exactly 25 points per $M; the 15th-best salary is a different
  percentile at QB, WR, CB and K; QB $40M -> 1000 is a convention.
- The Colors engine matches the salary table because it was **fitted** to it
  (`calibrate-weights.mjs` -> `salary-reference.json`; `derivedWeights = slotWins20 / 0.00254`). The
  measured match (rho 0.992, MAE 7.1, top-5 5/5, zero inversions) is a regression test for the fit.
- The unfitted Pre-Colors engine overvalues the secondary (+147 mean vs salary; CB3 +270) and the kicker
  (+234), and undervalues WR1 (-216) and WR2 (-164). It is **not** a literal copy of the Owner's personal
  table (MAE 296.6 vs 107.5; rho 0.708 vs 0.682).
- The next step is a **data anchor** (snaps x EPA/play above replacement x points/EPA x wins/point,
  2015-2021 fit / 2022-2024 test), pre-registered, with an independent verifier. The defensive side,
  especially CB3, is the hard part; report it as a band, not a point.

## Files

- `_agents/ds/notes/ENGINE-BIAS-AUDIT-2026-11-08.md` — the full audit and methodology.
- `_agents/ds/notes/innovation-2026-11-08.md` — answers to the 60 council questions (6 UNKNOWN, the rest
  INFERRED or better).
- `_agents/ds/notes/HYPOTHESIS-LEDGER.md` — H-DS-001/002 SUPPORTED, H-DS-003 OPEN.
- `_agents/ds/tools/bias-audit.mjs` — compare any measured curve to any table; `--selftest` PASS (7 fixtures).
- `_agents/ds/tools/anchor-compare.mjs` — data-anchor calculator; `--selftest` PASS (9 assertions).
- `_agents/ds/tools/fixtures/engine-bias-audit.json` — the real audit inputs.
- `_agents/ds/tools/fixtures/anchor-example.json` — **illustrative only**, not real data.
- `_agents/ds/snapshots/engine-bias-audit-2026-11-08.md` — the generated audit output.
- `inbox/20261108-0000-ds-P-284-innovation-2026-11-08.md` — the inbox summary.
- `_agents/ds/DS.md` — the updated lane file.

## How to run

```sh
node _agents/ds/tools/bias-audit.mjs --selftest
node _agents/ds/tools/bias-audit.mjs \
  --config _agents/ds/tools/fixtures/engine-bias-audit.json \
  --markdown /tmp/audit.md
node _agents/ds/tools/anchor-compare.mjs --selftest
node _agents/ds/tools/anchor-compare.mjs --schema
```

## Constraints

No product HTML, protected constant, or shared governance file was touched. The product hash is unchanged:
Pre-Colors `40233d6be00e987c` (the original, personal-table build). Nothing here is a patch; the only
proposed changes are the methodology and the two read-only tools.

## Labels

The audit numbers are VERIFIED by the fixture run; the causal reading (premium = bias vs football truth) is
INFERRED; the salary-method critique is INFERRED from the table arithmetic and the `_note`; the data-anchor
protocol is a proposal. The six UNKNOWN questions in the 60-answer file name the experiment that would
settle them.
